const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Player = sequelize.define(
  'Player',
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    email: {
      type: DataTypes.STRING(255),
      unique: true,
      allowNull: false,
      validate: {
        isEmail: true,
      },
    },
    username: {
      type: DataTypes.STRING(50),
      unique: true,
      allowNull: false,
    },
    passwordHash: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    role: {
      type: DataTypes.ENUM('player', 'admin'),
      allowNull: false,
      defaultValue: 'player',
    },
    status: {
      type: DataTypes.ENUM('active', 'blocked'),
      allowNull: false,
      defaultValue: 'active',
    },
    balance: {
      type: DataTypes.DECIMAL(18, 4),
      allowNull: false,
      defaultValue: 0.0,
    },
  },
  {
    tableName: 'players',
    indexes: [
      { fields: ['email'] },
      { fields: ['username'] },
    ],
  }
);

module.exports = Player;
