const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const config = require('./config/env');
const routes = require('./routes');
const notFound = require('./middleware/notFound');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Security headers
app.use(helmet());

// CORS
app.use(cors({ origin: '*', credentials: true }));

// Body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logging
app.use(
  morgan(config.isDev ? 'dev' : 'combined', {
    stream: {
      write: (msg) => {
        process.stdout.write(msg);
      },
    },
  })
);

// API routes
app.use('/api', routes);

// 404 + error handling
app.use(notFound);
app.use(errorHandler);

module.exports = app;
