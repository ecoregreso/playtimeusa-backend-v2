const { verifyAccessToken } = require('../utils/jwt');
const { Player } = require('../models');

function auth(requiredRole = null) {
  return async (req, res, next) => {
    try {
      const header = req.headers['authorization'] || '';
      const token = header.startsWith('Bearer ') ? header.slice(7) : null;

      if (!token) {
        return res.status(401).json({ error: 'Missing authorization token' });
      }

      let decoded;
      try {
        decoded = verifyAccessToken(token);
      } catch (err) {
        return res.status(401).json({ error: 'Invalid or expired token' });
      }

      const player = await Player.findByPk(decoded.id);
      if (!player || player.status === 'blocked') {
        return res.status(401).json({ error: 'Invalid or blocked account' });
      }

      if (requiredRole && player.role !== requiredRole) {
        return res.status(403).json({ error: 'Forbidden' });
      }

      req.user = {
        id: player.id,
        email: player.email,
        username: player.username,
        role: player.role,
      };

      next();
    } catch (err) {
      next(err);
    }
  };
}

module.exports = auth;
