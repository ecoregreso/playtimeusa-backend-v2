const express = require('express');
const router = express.Router();

const healthRoutes = require('./health.routes');
const authRoutes = require('./auth.routes');

router.use('/health', healthRoutes);
router.use('/auth', authRoutes);

// future:
// router.use('/cashier', require('./cashier.routes'));

module.exports = router;
