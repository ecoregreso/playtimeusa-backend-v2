const http = require('http');
const app = require('./app');
const config = require('./config/env');
const { initDatabase } = require('./config/database');

const server = http.createServer(app);

async function start() {
  try {
    await initDatabase();

    server.listen(config.port, () => {
      console.log(
        `[STARTUP] Server listening on http://localhost:${config.port} in ${config.env} mode`
      );
    });
  } catch (err) {
    console.error('[STARTUP] error:', err);
    process.exit(1);
  }
}

process.on('unhandledRejection', (reason) => {
  console.error('[UNHANDLED REJECTION]', reason);
});

process.on('uncaughtException', (err) => {
  console.error('[UNCAUGHT EXCEPTION]', err);
  process.exit(1);
});

start();
